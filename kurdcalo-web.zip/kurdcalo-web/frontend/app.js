// app.js - no framework, no build step. Talks to the backend defined in
// config.js. The only thing resembling a "secret" that ever touches this
// file is the backend's public URL - the actual GEMINI_API_KEY never
// leaves the server (see backend/app.py and vision.py).

(() => {
  const els = {
    quotaPill: document.getElementById("quotaPill"),
    quotaText: document.getElementById("quotaText"),

    uploadCard: document.getElementById("uploadCard"),
    dropzone: document.getElementById("dropzone"),
    dropzoneEmpty: document.getElementById("dropzoneEmpty"),
    previewImg: document.getElementById("previewImg"),
    fileInput: document.getElementById("fileInput"),
    analyzeBtn: document.getElementById("analyzeBtn"),

    loadingCard: document.getElementById("loadingCard"),

    resultCard: document.getElementById("resultCard"),
    resetBtn: document.getElementById("resetBtn"),
    kcalValue: document.getElementById("kcalValue"),
    proteinValue: document.getElementById("proteinValue"),
    carbsValue: document.getElementById("carbsValue"),
    fatValue: document.getElementById("fatValue"),
    foodsList: document.getElementById("foodsList"),
    insightText: document.getElementById("insightText"),
    noteText: document.getElementById("noteText"),
    analyzeAgainBtn: document.getElementById("analyzeAgainBtn"),

    noFoodCard: document.getElementById("noFoodCard"),
    noFoodMessage: document.getElementById("noFoodMessage"),
    noFoodRetryBtn: document.getElementById("noFoodRetryBtn"),

    quotaCard: document.getElementById("quotaCard"),
    quotaMessage: document.getElementById("quotaMessage"),

    errorCard: document.getElementById("errorCard"),
    errorMessage: document.getElementById("errorMessage"),
    errorRetryBtn: document.getElementById("errorRetryBtn"),
  };

  let selectedFile = null;

  const ALL_STATE_CARDS = [
    els.uploadCard, els.loadingCard, els.resultCard,
    els.noFoodCard, els.quotaCard, els.errorCard,
  ];

  function showOnly(card) {
    for (const c of ALL_STATE_CARDS) c.hidden = c !== card;
  }

  function fmt(n) {
    if (n === null || n === undefined) return "0";
    return Math.round(n).toString();
  }

  // --- Quota pill (best-effort display, server is always the real check) --
  async function refreshQuotaPill() {
    try {
      const res = await fetch(`${API_BASE_URL}/api/quota`, { credentials: "include" });
      if (!res.ok) return;
      const data = await res.json();
      els.quotaText.textContent = `${data.remaining} لە ${data.limit} سکانی ئەمڕۆ ماوە`;
      els.quotaPill.hidden = false;
    } catch (_) {
      // Non-fatal - the pill is a nicety, not required for the app to work.
    }
  }

  // --- File selection -------------------------------------------------
  els.dropzone.addEventListener("click", (e) => {
    // label already triggers the input; this guard avoids double-firing
    // when the click lands on the <img> inside it.
  });

  els.fileInput.addEventListener("change", () => {
    const file = els.fileInput.files[0];
    if (!file) return;
    selectedFile = file;
    const url = URL.createObjectURL(file);
    els.previewImg.src = url;
    els.previewImg.hidden = false;
    els.dropzoneEmpty.hidden = true;
    els.analyzeBtn.disabled = false;
  });

  function resetUploadCard() {
    selectedFile = null;
    els.fileInput.value = "";
    els.previewImg.hidden = true;
    els.dropzoneEmpty.hidden = false;
    els.analyzeBtn.disabled = true;
  }

  // --- Analyze ----------------------------------------------------------
  async function analyze() {
    if (!selectedFile) return;
    showOnly(els.loadingCard);

    const formData = new FormData();
    formData.append("photo", selectedFile);

    try {
      const res = await fetch(`${API_BASE_URL}/api/analyze`, {
        method: "POST",
        body: formData,
        credentials: "include", // required so the device-id cookie is sent/stored
      });
      const data = await res.json();

      if (data.ok && data.status === "ok") {
        renderResult(data);
        return;
      }
      if (data.ok && data.status === "no_food") {
        els.noFoodMessage.textContent = data.message || "تکایە وێنەیەکی ڕوونتر هەڵبژێرە.";
        showOnly(els.noFoodCard);
        refreshQuotaPill();
        return;
      }
      if (data.error_code === "quota_exceeded") {
        els.quotaMessage.textContent = data.message;
        showOnly(els.quotaCard);
        return;
      }
      // Any other error_code (rate_limited, file_too_large, invalid_file_type,
      // service_busy, analysis_failed, internal_error, ...)
      els.errorMessage.textContent = data.message || "هەڵەیەکی چاوەڕواننەکراو ڕوویدا.";
      showOnly(els.errorCard);
    } catch (err) {
      els.errorMessage.textContent = "ناتوانرێت پەیوەندی بە سێرڤەرەوە بکرێت. ئینتەرنێتەکەت بپشکنە.";
      showOnly(els.errorCard);
    }
  }

  function renderResult(data) {
    els.kcalValue.textContent = fmt(data.total_kcal);
    els.proteinValue.textContent = `${fmt(data.total_protein_g)}g`;
    els.carbsValue.textContent = `${fmt(data.total_carbs_g)}g`;
    els.fatValue.textContent = `${fmt(data.total_fat_g)}g`;

    els.foodsList.innerHTML = "";
    for (const food of data.foods || []) {
      const row = document.createElement("div");
      row.className = "food-row";
      row.innerHTML = `
        <span class="food-row-name">${food.emoji || "🍽️"} ${escapeHtml(food.name_kurdish || "")}</span>
        <span class="food-row-kcal">${fmt(food.kcal)} کالۆری</span>
      `;
      els.foodsList.appendChild(row);
    }

    if (data.insight_kurdish) {
      els.insightText.textContent = data.insight_kurdish;
      els.insightText.hidden = false;
    } else {
      els.insightText.hidden = true;
    }
    if (data.note_kurdish) {
      els.noteText.textContent = data.note_kurdish;
      els.noteText.hidden = false;
    } else {
      els.noteText.hidden = true;
    }

    showOnly(els.resultCard);
    refreshQuotaPill();
  }

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  function startOver() {
    resetUploadCard();
    showOnly(els.uploadCard);
  }

  els.analyzeBtn.addEventListener("click", analyze);
  els.resetBtn.addEventListener("click", startOver);
  els.analyzeAgainBtn.addEventListener("click", startOver);
  els.noFoodRetryBtn.addEventListener("click", startOver);
  els.errorRetryBtn.addEventListener("click", startOver);

  // --- Init ---------------------------------------------------------------
  showOnly(els.uploadCard);
  refreshQuotaPill();
})();
