// EDIT THIS after you deploy the backend to Render - see README.md.
// This is the only file you need to change to connect the frontend to
// your own backend. No build step, no bundler - plain static files.
const API_BASE_URL = "https://your-backend-name.onrender.com";
